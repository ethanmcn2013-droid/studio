Signal Studio - student ambassador kit (K-series)
==================================================

Nine kits: UL, TUS and MIC - three per campus. Assembled in August,
in hand before societies week begins.

  k0-welcome-letter-print.pdf        A5 - print and SIGN BY HAND before boxing
  k1-onboarding-guide-print.pdf      A5 booklet, 6pp - ten minutes cover to cover
  k2-template-*.pdf                  A5 sheets - The Ball / The Trip / The Campaign / The AGM Handover
  k3-committee-qr-card-*.pdf         55x85mm - SPECIMEN until the QR destination is confirmed
  k4-notebook-procurement-spec.pdf   The one quality object - order a sample first

Print notes: all *-print.pdf carry 3mm bleed + crop marks; convert to PDF/X
at prepress. Cards on the same heavy uncoated stock as the venue set
(350-400gsm); letter on 120gsm uncoated; guide saddle-stitched or folded.

Budget: Line K - kits and stipends together (2,000 EUR).
Contact: hello@signalstudio.ie
