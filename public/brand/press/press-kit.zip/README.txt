Signal Studio - press kit (assembling; complete July 2026)
==========================================================

Inside:
  signal-studio-press-release-draft.pdf   Embargo 1 September 2026 - draft until founder approval
  signal-studio-fact-sheet-draft.pdf      Every number checkable at plan.signalstudio.ie
  signal-studio-founder-story.pdf         Why this was built
  signal-studio-brand-usage-notes.pdf     Marks, palette, rules for designers

Coming before outreach begins (July):
  Founder photography - professional but human, at work in Limerick
  Product screenshots - all four products, captioned, honest about what's shipped

Wordmark/logo masters (SVG + PNG, all sizes):
  https://signalstudio.ie/brand/signal-studio-brand-kit.zip

Contact: hello@signalstudio.ie - direct line to the founder, same-day reply
through the launch window.
